# CIFAR10
A project involving image classification using CNN, acquired accuracy of approx. 87%. The projects aims at training a CNN model to classify images into 10 different classes.Training was done with 50,000 images, performed testing over 10,000 images.
